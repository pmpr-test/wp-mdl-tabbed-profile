<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46f4a70c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TabbedProfile; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
